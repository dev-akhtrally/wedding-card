import { useState, useRef, useEffect, useCallback } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import styles from '../styles/Capture.module.css';

const STEPS = { PREVIEW: 'preview', REVIEW: 'review', UPLOADING: 'uploading', SUCCESS: 'success' };

export default function Capture() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  const [step, setStep] = useState(STEPS.PREVIEW);
  const [capturedImage, setCapturedImage] = useState(null);
  const [caption, setCaption] = useState('');
  const [guestName, setGuestName] = useState('');
  const [error, setError] = useState('');
  const [camReady, setCamReady] = useState(false);
  const [facingMode, setFacingMode] = useState('environment');
  const [flash, setFlash] = useState(false);
  const [uploadedPhoto, setUploadedPhoto] = useState(null);

  const startCamera = useCallback(async (mode = facingMode) => {
    // Stop existing stream
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
    }
    setCamReady(false);
    setError('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: mode },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current.play();
          setCamReady(true);
        };
      }
    } catch (err) {
      setError('Camera access denied. Please allow camera permissions and try again.');
    }
  }, [facingMode]);

  useEffect(() => {
    startCamera();
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
    };
  }, []);

  const flipCamera = () => {
    const newMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(newMode);
    startCamera(newMode);
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    setFlash(true);
    setTimeout(() => setFlash(false), 300);

    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext('2d');
    // Mirror if using front camera
    if (facingMode === 'user') {
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
    }
    ctx.drawImage(video, 0, 0);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    setCapturedImage(dataUrl);
    setStep(STEPS.REVIEW);

    // Stop camera after capture
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
    }
  };

  const retake = () => {
    setCapturedImage(null);
    setCaption('');
    setStep(STEPS.PREVIEW);
    startCamera();
  };

  const upload = async () => {
    if (!capturedImage) return;
    setStep(STEPS.UPLOADING);
    setError('');

    try {
      const res = await fetch('/api/photos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: capturedImage,
          caption: caption.trim(),
          name: guestName.trim() || 'Anonymous Guest',
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');
      setUploadedPhoto(data);
      setStep(STEPS.SUCCESS);
    } catch (err) {
      setError(err.message || 'Something went wrong. Please try again.');
      setStep(STEPS.REVIEW);
    }
  };

  return (
    <>
      <Head>
        <title>Capture a Moment · Wedding Day</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
      </Head>

      <div className={styles.page}>
        {/* Header */}
        <header className={styles.header}>
          <Link href="/" className={styles.backBtn}>← Gallery</Link>
          <div className={styles.headerCenter}>
            <span className={styles.headerEyebrow}>Wedding Day</span>
            <span className={styles.headerDot}>✦</span>
            <span className={styles.headerTitle}>
              {step === STEPS.PREVIEW && 'Take a Photo'}
              {step === STEPS.REVIEW && 'Review'}
              {step === STEPS.UPLOADING && 'Sharing…'}
              {step === STEPS.SUCCESS && 'Shared!'}
            </span>
          </div>
          <div style={{ width: '5rem' }} />
        </header>

        <main className={styles.main}>

          {/* ── CAMERA STEP ── */}
          {step === STEPS.PREVIEW && (
            <div className={styles.cameraSection}>
              {error ? (
                <div className={styles.errorBox}>
                  <p className={styles.errorIcon}>◎</p>
                  <p>{error}</p>
                  <button className={styles.retryBtn} onClick={() => startCamera()}>
                    Try Again
                  </button>
                </div>
              ) : (
                <>
                  <div className={styles.viewfinder}>
                    <video
                      ref={videoRef}
                      className={styles.video}
                      autoPlay
                      playsInline
                      muted
                      style={{ transform: facingMode === 'user' ? 'scaleX(-1)' : 'none' }}
                    />
                    {flash && <div className={styles.flashOverlay} />}
                    {!camReady && (
                      <div className={styles.camLoading}>
                        <div className={styles.camSpinner} />
                        <p>Starting camera…</p>
                      </div>
                    )}
                    {/* Corner guides */}
                    <div className={styles.cornerTL} />
                    <div className={styles.cornerTR} />
                    <div className={styles.cornerBL} />
                    <div className={styles.cornerBR} />
                  </div>

                  <canvas ref={canvasRef} style={{ display: 'none' }} />

                  <div className={styles.controls}>
                    <button
                      className={styles.flipBtn}
                      onClick={flipCamera}
                      disabled={!camReady}
                      aria-label="Flip camera"
                    >
                      ⟳
                    </button>
                    <button
                      className={styles.shutterBtn}
                      onClick={capturePhoto}
                      disabled={!camReady}
                      aria-label="Take photo"
                    >
                      <span className={styles.shutterInner} />
                    </button>
                    <div style={{ width: '3rem' }} />
                  </div>

                  <p className={styles.hint}>Tap the shutter to capture your moment</p>
                </>
              )}
            </div>
          )}

          {/* ── REVIEW STEP ── */}
          {step === STEPS.REVIEW && (
            <div className={styles.reviewSection}>
              <div className={styles.previewFrame}>
                <img src={capturedImage} alt="Your photo" className={styles.previewImg} />
                <div className={styles.previewDecor}>◆</div>
              </div>

              <div className={styles.form}>
                <div className={styles.formGroup}>
                  <label className={styles.label}>Your Name</label>
                  <input
                    className={styles.input}
                    type="text"
                    placeholder="e.g. Sarah & James"
                    value={guestName}
                    onChange={e => setGuestName(e.target.value)}
                    maxLength={60}
                  />
                </div>

                <div className={styles.formGroup}>
                  <label className={styles.label}>Add a Caption</label>
                  <textarea
                    className={styles.textarea}
                    placeholder="Share a wish, memory, or message…"
                    value={caption}
                    onChange={e => setCaption(e.target.value)}
                    rows={3}
                    maxLength={200}
                  />
                  <span className={styles.charCount}>{caption.length}/200</span>
                </div>

                {error && <p className={styles.errorMsg}>{error}</p>}

                <div className={styles.formActions}>
                  <button className={styles.retakeBtn} onClick={retake}>
                    ↩ Retake
                  </button>
                  <button className={styles.shareBtn} onClick={upload}>
                    Share Moment ✦
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ── UPLOADING ── */}
          {step === STEPS.UPLOADING && (
            <div className={styles.uploadingState}>
              <div className={styles.uploadOrb}>
                <div className={styles.uploadRing} />
                <span>✦</span>
              </div>
              <h2>Sharing your moment…</h2>
              <p>Adding to the memory wall</p>
            </div>
          )}

          {/* ── SUCCESS ── */}
          {step === STEPS.SUCCESS && (
            <div className={styles.successState}>
              <div className={styles.successIcon}>✦</div>
              <h2>Beautifully shared!</h2>
              <p>Your moment is now on the memory wall for everyone to see.</p>

              {uploadedPhoto && (
                <div className={styles.successPreview}>
                  <img src={uploadedPhoto.image_url} alt="Uploaded" />
                  {uploadedPhoto.caption && (
                    <p className={styles.successCaption}>"{uploadedPhoto.caption}"</p>
                  )}
                </div>
              )}

              <div className={styles.successActions}>
                <button
                  className={styles.anotherBtn}
                  onClick={() => {
                    setCapturedImage(null);
                    setCaption('');
                    setGuestName('');
                    setUploadedPhoto(null);
                    setStep(STEPS.PREVIEW);
                    startCamera();
                  }}
                >
                  ◎ Take Another
                </button>
                <Link href="/" className={styles.galleryBtn}>
                  View Memory Wall →
                </Link>
              </div>
            </div>
          )}
        </main>
      </div>
    </>
  );
}
