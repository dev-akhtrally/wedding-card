import { useState, useEffect, useRef } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import styles from '../styles/Gallery.module.css';

export default function Gallery() {
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [lastCount, setLastCount] = useState(0);
  const intervalRef = useRef(null);

  const fetchPhotos = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const res = await fetch('/api/photos');
      const data = await res.json();
      if (Array.isArray(data)) {
        setPhotos(data);
        setLastCount(data.length);
      }
    } catch (e) {
      console.error(e);
    }
    if (!silent) setLoading(false);
  };

  useEffect(() => {
    fetchPhotos();
    intervalRef.current = setInterval(() => fetchPhotos(true), 8000);
    return () => clearInterval(intervalRef.current);
  }, []);

  const formatTime = (iso) => {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <>
      <Head>
        <title>Our Wedding Day · Memory Wall</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="Wedding photo wall — capture and share your moments" />
      </Head>

      <div className={styles.page}>
        {/* Header */}
        <header className={styles.header}>
          <div className={styles.headerInner}>
            <div className={styles.headerDecor}>✦</div>
            <div className={styles.headerText}>
              <p className={styles.headerEyebrow}>Wedding Day</p>
              <h1 className={styles.headerTitle}>Memory Wall</h1>
              <p className={styles.headerSub}>Every moment, captured with love</p>
            </div>
            <div className={styles.headerDecor}>✦</div>
          </div>
          <div className={styles.headerRule}>
            <span className={styles.ruleLeft} />
            <span className={styles.ruleDiamond}>◆</span>
            <span className={styles.ruleRight} />
          </div>
          <div className={styles.headerActions}>
            <Link href="/capture" className={styles.captureBtn}>
              <span className={styles.captureBtnIcon}>◎</span>
              <span>Take a Photo</span>
            </Link>
            <p className={styles.photoCount}>
              {photos.length} {photos.length === 1 ? 'moment' : 'moments'} shared
            </p>
          </div>
        </header>

        {/* Gallery */}
        <main className={styles.main}>
          {loading ? (
            <div className={styles.loadingState}>
              <div className={styles.loadingOrb} />
              <p>Gathering memories…</p>
            </div>
          ) : photos.length === 0 ? (
            <div className={styles.emptyState}>
              <div className={styles.emptyIcon}>◎</div>
              <h2>No photos yet</h2>
              <p>Be the first to capture a moment!</p>
              <Link href="/capture" className={styles.captureBtn}>
                Take the First Photo
              </Link>
            </div>
          ) : (
            <div className={styles.masonry}>
              {photos.map((photo, i) => (
                <div
                  key={photo.id}
                  className={styles.photoCard}
                  style={{ '--delay': `${(i % 12) * 0.05}s` }}
                  onClick={() => setSelectedPhoto(photo)}
                >
                  <div className={styles.photoFrame}>
                    <img
                      src={photo.image_url}
                      alt={photo.caption || 'Wedding moment'}
                      className={styles.photoImg}
                      loading="lazy"
                    />
                    <div className={styles.photoOverlay}>
                      <span className={styles.photoZoom}>⊕</span>
                    </div>
                  </div>
                  <div className={styles.photoMeta}>
                    {photo.caption && (
                      <p className={styles.photoCaption}>"{photo.caption}"</p>
                    )}
                    <div className={styles.photoFooter}>
                      <span className={styles.photoName}>{photo.name || 'Anonymous'}</span>
                      <span className={styles.photoTime}>{formatTime(photo.created_at)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>

        {/* Lightbox */}
        {selectedPhoto && (
          <div className={styles.lightbox} onClick={() => setSelectedPhoto(null)}>
            <div className={styles.lightboxInner} onClick={e => e.stopPropagation()}>
              <button className={styles.lightboxClose} onClick={() => setSelectedPhoto(null)}>
                ✕
              </button>
              <img
                src={selectedPhoto.image_url}
                alt={selectedPhoto.caption}
                className={styles.lightboxImg}
              />
              <div className={styles.lightboxMeta}>
                {selectedPhoto.caption && (
                  <p className={styles.lightboxCaption}>"{selectedPhoto.caption}"</p>
                )}
                <p className={styles.lightboxName}>— {selectedPhoto.name || 'Anonymous Guest'}</p>
              </div>
            </div>
          </div>
        )}

        <footer className={styles.footer}>
          <p>Made with love ✦ Refresh happens automatically</p>
        </footer>
      </div>
    </>
  );
}
